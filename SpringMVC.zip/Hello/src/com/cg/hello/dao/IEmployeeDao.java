package com.cg.hello.dao;

import java.util.List;

import com.cg.hello.bean.Employee;



public interface IEmployeeDao {
	public Employee addEmployee(Employee employee);
	public List<Employee> getAllEmployee();
	public Employee search(int id);
	public boolean deleteEmployee(int id);
}
