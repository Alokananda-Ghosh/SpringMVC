package com.cg.hello.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hello.bean.Employee;
import com.cg.hello.service.IService;



@Controller
public class Controllerr {
	@Autowired
	IService iso;

	public IService getIso() {
		return iso;
	}

	public void setIso(IService iso) {
		this.iso = iso;
	}

	@RequestMapping("/menu")
	public String menu() {

		return "menu";
	}

	@RequestMapping("/addEmployee")
	public ModelAndView addEmployee() {
		Employee employee = new Employee();
		return new ModelAndView("addEmployee", "employee", employee);
	}

	@RequestMapping("/Success")
	public ModelAndView addTrainee(@ModelAttribute("employee") @Valid Employee employee, BindingResult result) {
		ModelAndView mv = null;

		if (!result.hasErrors()) {
			employee = iso.addEmployee(employee);
			mv = new ModelAndView("Success");
			mv.addObject("id", employee.getId());
			//mv.addObject("name", employee.getName());
		} else {
			mv = new ModelAndView("addEmployee", "employee", employee);
		}

		return mv;
	}
	@RequestMapping("/ShowAll")
	public ModelAndView showAllTrainee() {
		List<Employee> employee = iso.getAllEmployee();
		return new ModelAndView("ShowAll","employee",employee);
	}
	@RequestMapping("/Search")
	public String Search() {
		return "Search";
	}
	
	@RequestMapping("/Search2")
	public ModelAndView search(@RequestParam("id") int id) {
		ModelAndView mv = null;
		Employee employee =iso.search(id);
		if(employee!=null) {
			mv = new ModelAndView("ShowEmployee","employee",employee); 
		}
		else
		mv = new ModelAndView("Search", "message", "Please, Enter a valid Id or the id is not present");
		
		return mv;
	}
	@RequestMapping("/Delete")
	public String Delete() {
		return "Delete";	
	}
	@RequestMapping("/DeleteEmployee")
	public ModelAndView deleteTrainee(@RequestParam("id") int id) {
		ModelAndView mv = null;
		if(iso.deleteEmployee(id)) {
			mv = new ModelAndView("menu", "message", "Deleted successfully!!!!"); 
		}
		else
		mv = new ModelAndView("Delete", "message", "Please, Enter a valid Id or the id is not present");
		
		return mv;
	}
}