package com.cg.hello.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hello.bean.Employee;
import com.cg.hello.dao.EmployeeDaoImpl;
import com.cg.hello.dao.IEmployeeDao;

@Service
public class ServiceImpl implements IService {
	@Autowired
	IEmployeeDao imp;

	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return imp.addEmployee(employee);
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return imp.getAllEmployee();
	}

	@Override
	public Employee search(int id) {
		// TODO Auto-generated method stub
		return imp.search(id);
	}

	@Override
	public boolean deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return imp.deleteEmployee(id);
	}

}
