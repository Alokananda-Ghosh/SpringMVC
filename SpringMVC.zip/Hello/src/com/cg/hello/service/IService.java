package com.cg.hello.service;

import java.util.List;

import com.cg.hello.bean.Employee;

public interface IService {
	public Employee addEmployee(Employee employee);
	public List<Employee> getAllEmployee();
	public Employee search(int id);
	public boolean deleteEmployee(int id);
}
